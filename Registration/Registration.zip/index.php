<?php 

   session_start();
    include("admin/include/config.php");
    error_reporting(1);
 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="style.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
     
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title> Registration Form | Tech Wizards 2.0 </title> 
</head>
<script type="text/javascript">
     function CourseChangeFunction() {
        selectElement_fee = document.querySelector('#student_course');
        selectElement_fee_output = selectElement_fee.value;
        if(selectElement_fee_output == "123")
        {
       document.getElementById("student_specilization").readOnly = false;
       document.getElementById("student_specilization").disabled = false;
       //document.getElementById("student_specilization").value=" ";
       document.getElementById("student_specilization").required = true;
        
         }
         else 
         {
              document.getElementById("student_specilization").readOnly = true;
       document.getElementById("student_specilization").disabled = true;
       document.getElementById("student_specilization").value="none";
       document.getElementById("student_specilization").required = false;

         }
     }
    
</script>
 <body class="sb-nav-fixed" oncontextmenu="return false">
    <div class="container">
        <header>
            <img src="img/img.png" alt="" width="100px;" height="100px;">
            <img class="imp" src="img/imp.png" alt="In Association With" width="300px;" height="100px;" >
            

            <h2>TEKVISORY PRESENTS</h2>

            <h2>TECH WIZARDS 2.0 
            
            </h2>
            <h3>Registration Form</h3>

           
            
        </header>
        
<?php 
        extract($_POST);
extract($_GET);
        if(isset($Registration))
{
$activesessionquery=mysqli_query($con,"SELECT * FROM `session` WHERE `status` ='Active'");
$resactivesessionquery=mysqli_fetch_assoc($activesessionquery);
$activesession_record_add=$resactivesessionquery['session_year'];
$activesession_record_add_full=$resactivesessionquery['fyear'];

$schoolquerycode=mysqli_query($con,"SELECT * FROM `school`");
$schoolquerycoderesult=mysqli_fetch_assoc($schoolquerycode);
$school_code=$schoolquerycoderesult['school_code'];
date_default_timezone_set('Asia/Kolkata');      
$date=date("d-m-Y h:i:sa");
$Currentdate=date("d-m-Y");

    $feesessionyearrecord=$activesession_record_add;
    $inputStudentAmountPaid=$_POST['TotalAmount'];
    $StudentName=$_POST['student_name'];
    $StudentId=$_POST['student_id'];
    $studentEmail=$_POST['student_email'];
    $studentNumber=$_POST['student_number'];
    $studentwhatsappnumber=$_POST['student_whatsappnumber'];
    $studentGender=$_POST['student_gender'];
    $studentCampus=$_POST['student_campus'];
    $studentCourse=$_POST['student_course'];
    $studentSemester=$_POST['student_semester'];
    $studentSpecilization=$_POST['student_specilization'];
      $studentdob=$_POST['student_dob'];

 $dateyear=$activesession_record_add_full;
    $startno="00001";
    $feestatus ="Rejected";
    $studentstatus ="InActive";
    $orderid=" ";

    $id1=$dateyear."".$school_code;
    $rsquery=mysqli_query($con,"SELECT * FROM `registration` WHERE `student_id`='$StudentId' AND `fee_status`='Active' AND `student_status`='Active'");
if (mysqli_num_rows($rsquery)>0)
{
    
        echo "<script language='javascript'>alert('your Process is already Completed');window.location='index.php'</script>";
        exit();
    
}

       $rsquery=mysqli_query($con,"SELECT * FROM `registration` WHERE `student_id`='$StudentId' AND `fee_status`='Rejected' AND `student_status`='InActive'");
if (mysqli_num_rows($rsquery)>0)
{
    if ($resultrow=mysqli_fetch_row($rsquery)) 
    {
$receiptnumberid=$resultrow['1'];
$hashcode=urlencode(base64_encode($receiptnumberid));
        echo "<script language='javascript'>alert('you are already registered with us  Please Complete Your Payment Process');window.location='Complete_PaymentProcess.php?id=$hashcode'</script>";
        exit();
    }
    //$receiptnumberid=$rs['1'];
    
}

$rs1=mysqli_query($con,"SELECT * FROM `registration` WHERE LEFT(`receipt_number`,6) LIKE '%$id1%' ORDER BY `payment_id` DESC LIMIT 1");
 if (mysqli_num_rows($rs1)>0)
{
    if ($row=mysqli_fetch_row($rs1)) 
    {
        $uid = $row['1'];
       // $get_numbers = str_replace("SR","",$uid);
        $id_increase = $uid+1;
        //$id_increase = $get_numbers+1;
        $get_string = str_pad($id_increase,6,0,STR_PAD_LEFT);
        //$id = "SR".$get_string;
        $id = $get_string;
   $hashcode=urlencode(base64_encode($id));
mysqli_query($con,"INSERT INTO `registration`(`receipt_number`, `student_id`, `student_name`, `student_gender`, `student_campus`, `student_course`, `student_specilization`, `student_semester`, `student_email`, `student_number`, `student_whatsappnumber`,`student_dob`, `paid_amount`, `paid_date`, `paid_mode`, `order_id`, `fee_status`, `student_status`, `createdtime`, `session`) VALUES ('$id','$StudentId','$StudentName','$studentGender','$studentCampus','$studentCourse','$studentSpecilization','$studentSemester','$studentEmail','$studentNumber','$studentwhatsappnumber','$studentdob','$inputStudentAmountPaid','$Currentdate','Online','$orderid','$feestatus','$studentstatus','$date','$feesessionyearrecord')") or die(mysqli_error());
 $_SESSION['OID']=mysqli_insert_id($con);
echo "<script language='javascript'>alert('Record Added Successfully  Please Complete Your Payment Process');window.location='Complete_PaymentProcess.php?id=$hashcode'</script>";

    exit();
    }
   
}  
else
{    
  
     $id=$dateyear."".$school_code."".$startno;
     $hashcode=urlencode(base64_encode($id));
mysqli_query($con,"INSERT INTO `registration`(`receipt_number`, `student_id`, `student_name`, `student_gender`, `student_campus`, `student_course`, `student_specilization`, `student_semester`, `student_email`, `student_number`, `student_whatsappnumber`,`student_dob`, `paid_amount`, `paid_date`, `paid_mode`, `order_id`, `fee_status`, `student_status`, `createdtime`, `session`) VALUES ('$id','$StudentId','$StudentName','$studentGender','$studentCampus','$studentCourse','$studentSpecilization','$studentSemester','$studentEmail','$studentNumber','$studentwhatsappnumber','$studentdob','$inputStudentAmountPaid','$Currentdate','Online','$orderid','$feestatus','$studentstatus','$date','$feesessionyearrecord')") or die(mysqli_error());
$_SESSION['OID']=mysqli_insert_id($con);
echo "<script language='javascript'>alert('You are Successfully registated With Please Complete Your Payment Process');window.location='Complete_PaymentProcess.php?id=$hashcode'</script>";


}

}


        ?>
        <form name="form" method="POST" action=""  onSubmit="return check();">
            <div class="form first">
                <div class="details personal">
                    <!--<span class="title">Personal Details</span>-->

                    <div class="fields">
                        <input type="hidden" name="TotalAmount" id="TotalAmount" value="50">
                        <div class="input-field">
                            <label>Full Name</label>
                            <input type="text" placeholder="Enter your name" name="student_name" id="student_name" required>
                        </div>

                        <div class="input-field">
                            <label>Student ID</label>
                            <input type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="student_id" id="student_id" placeholder="Enter student id Ex:- 21391043" required>
                        </div>

                        <div class="input-field">
                            <label>Email</label>
                            <input type="text" name="student_email" id="student_email" placeholder="Enter your email" required>
                        </div>

                        <div class="input-field">
                            <label>Mobile Number</label>
                            <input type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="student_number" id="student_number" placeholder="Enter mobile number" required>
                        </div>

                        <div class="input-field">
                            <label>WhatsApp Number</label>
                            <input type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  id="student_whatsappnumber" name="student_whatsappnumber" placeholder="Enter whatsapp number" required>
                        </div>

                        <div class="input-field">
                            <label>Select Gender</label>
                            <select required name="student_gender" id="student_gender">
                                <option disabled selected>Select</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Prefer Not To Say</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="details ID">
                    <span class="title">More Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Campus</label>
                            <select required name="student_campus" id="student_campus"  >
                                <option disabled selected>Select</option>
                                <?php
$campusselect=mysqli_query($con,"SELECT * FROM `campus` WHERE  `status`='Active'");
      while($resultcampusselect=mysqli_fetch_array($campusselect))
{

echo "<option value='$resultcampusselect[0]'>$resultcampusselect[1]</option>";

}
?>
                            </select>
                        </div>

                        <div class="input-field">
                            <label name="studentlabelcourse" id="studentlabelcourse">Course</label>
                            <select required name="student_course" id="student_course"  onchange="CourseChangeFunction()">
                                <option disabled selected>Select</option>
                               <?php
$courseselect=mysqli_query($con,"SELECT * FROM `course_detail` WHERE  `status`='Active'");
      while($resultcourseselect=mysqli_fetch_array($courseselect))
{

echo "<option value='$resultcourseselect[1]'>$resultcourseselect[2]</option>";

}
?>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Semester</label>
                            <select required name="student_semester" id="student_semester">
                                <option disabled selected>Select</option>
                                <option value="1">1</option>
                                <option value="3">3</option>
                                <option value="5">5</option>
                                <option value="7">7</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Specialization (Only For B.Tech Student)</label>
                            <select required name="student_specilization" id="student_specilization">
                                <option disabled selected>Select</option>
                                <option value="None">None</option>
                                <option value="CSE">CSE</option>
                               <option value="ME">ME</option>
                               <option value="IT">IT</option>
                               <option value="CE">CE</option>
                               <option value="CST">CST</option>
                               <option value="Computer Engg">Computer Engg</option>
                               <option value="AI & Data Sciences">AI & Data Sciences</option>
                               <option value="EEE">EEE</option>
                               <option value="BIO.TECH">BIO.TECH</option>
                               <option value="ECE">ECE</option>
                               <option value="PE">PE</option>
                               <option value="Artificial Intelligence & Machine Learning">Artificial Intelligence & Machine Learning</option>
                               <option value="COMPUTER ENGG (WITH ANY SPECIALIZATION)">COMPUTER ENGG (WITH ANY SPECIALIZATION)</option>
                               <option value="CST (WITH ANY SPECIALIZATION)">CST (WITH ANY SPECIALIZATION)</option>
                               <option value="ME (WITH ANY SPECIALIZATION)">ME (WITH ANY SPECIALIZATION)</option>
                               <option value="ECE (WITH ANY SPECIALIZATION)">ECE (WITH ANY SPECIALIZATION)</option>
                               <option value="EE (WITH ANY SPECIALIZATION)">EE (WITH ANY SPECIALIZATION)</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Date of Birth</label>
                            <input type="date" name="student_dob" id="student_dob" placeholder="Enter birth date" required>
                        </div>


                        <div class="input-field">
                            <label>Registration Date</label>
                            <input type="date" value="<?php echo date('Y-m-d'); ?>" placeholder="Enter your issued date" readonly required>
                        </div>

                        
                    </div>

                        <input type="Submit" class="sumbit" onsubmit="pay_now()"  name="Registration" id="Registration">
                       
                    </div>
                </div> 
            </div>
        </form>
    </div>

  <script>
    function pay_now(){
       
        var TotalAmount = "50";
        var student_name = jQuery('#student_name').val();
        var student_id = jQuery('#student_id').val();
        var student_email = jQuery('#student_email').val();
        var student_number = jQuery('#student_number').val();
        var student_whatsappnumber = jQuery('#student_whatsappnumber').val();
        var student_gender = jQuery('#student_gender').val();
        var student_campus = jQuery('#student_campus').val();
        var student_course = jQuery('#student_course').val();
        var student_semester = jQuery('#student_semester').val();
        var student_specilization = jQuery('#student_specilization').val();
        var student_dob = jQuery('#student_dob').val();
       
        
        
         jQuery.ajax({
               type:'POST',
               url:'payment_process.php',
               data:"TotalAmount="+TotalAmount+"&student_name="+student_name+"&student_id="+student_id+"&student_email="+student_email+"&student_number="+student_number+"&student_whatsappnumber="+student_whatsappnumber+"&student_gender="+student_gender+"&student_campus="+student_campus+"&student_course="+student_course+"&student_semester="+student_semester+"&student_specilization="+student_specilization+"&student_dob="+student_dob,
               success:function(result){
                   var options = {
                        "key": "rzp_test_3XbAkeMuMEWii0", 
                        "amount": TotalAmount*100, 
                        "currency": "INR",
                        "name": "Paritosh Bisht",
                        "description": "Test Transaction",
                        "image": "https://image.freepik.com/free-vector/logo-sample-text_355-558.jpg",
                        "handler": function (response){
                           jQuery.ajax({
                               type:'POST',
                               url:'payment_process.php',
                               data:"invoice_number="+response.razorpay_payment_id,
                               success:function(result){
                                window.alert("Thank You For Payment")
                                   window.location.href="Student_fee_online_pay.php?id=Fee%20receipt||mid%20id=19||feestudentmodule";
                               }
                           });
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.open();
               }
           });
        
        
    }
</script>
 <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

</body>
</html>