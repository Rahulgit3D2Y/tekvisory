<?php 

   session_start();
    include("admin/include/config.php");
   ?>

 <?php
 extract($_POST);
 $finalstatus="Active";
 //echo $_SESSION['receiptnumber'];
 //echo $_SESSION['messgae'];
 date_default_timezone_set('Asia/Kolkata');      
$date=date("d-m-Y h:i:sa");

 if(isset($_POST['TotalAmount']) && isset($_POST['student_id'])&& isset($_POST['cdate'])&& isset($_POST['receiptnumber']))
{
 $StudentId=$_POST['student_id'];
 $inputStudentAmountPaid=$_POST['TotalAmount'];
  $inputStudentFeeDate=$_POST['cdate'];
  $inputStudentReceipt=$_POST['receiptnumber'];

  $studentupdatequery="UPDATE `registration` SET `cpaid_date`='$inputStudentFeeDate',`feeupdatetime`='$date' WHERE `receipt_number` = '$inputStudentReceipt'";
mysqli_query($con,$studentupdatequery);
$_SESSION['receiptnumber']=$inputStudentReceipt;
}

if( isset($_POST['invoice_number']) && isset($_SESSION['receiptnumber'])){
    $invoice_number=$_POST['invoice_number'];
    mysqli_query($con,"UPDATE `registration` SET `fee_status`='$finalstatus',`student_status`='$finalstatus',`order_id`='$invoice_number' where `receipt_number`='".$_SESSION['receiptnumber']."'");
  // $_SESSION['message']="1";

}


?>