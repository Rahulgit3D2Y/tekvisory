<?php 

   session_start();
    include("admin/include/config.php");
    error_reporting(1);

    extract($_REQUEST);
foreach($_GET as $userid=>$useritem)
  $id = $_GET[$userid] = base64_decode(urldecode($useritem));
 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="style.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
     
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title> Registration Form | Tech Wizards 2.0 </title> 
</head>
<style type="text/css">'
</style>

 <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script type="text/javascript">
     function CourseChangeFunction() {
        selectElement_fee = document.querySelector('#student_course');
        selectElement_fee_output = selectElement_fee.value;
        if(selectElement_fee_output == "123")
        {
       document.getElementById("student_specilization").readOnly = false;
       document.getElementById("student_specilization").disabled = false;
       //document.getElementById("student_specilization").value=" ";
       document.getElementById("student_specilization").required = true;
        
         }
         else 
         {
              document.getElementById("student_specilization").readOnly = true;
       document.getElementById("student_specilization").disabled = true;
       document.getElementById("student_specilization").value="NaN";
       document.getElementById("student_specilization").required = false;

         }
     }
    
</script>
 <body class="sb-nav-fixed" oncontextmenu="return false">
<?php
$updatedatatstudentstatusquery=mysqli_query($con,"SELECT * FROM `registration` WHERE `receipt_number`='$id'");
$resultstatus=mysqli_fetch_assoc($updatedatatstudentstatusquery)or die("");
$studentstatus=$resultstatus['fee_status'];

if ($studentstatus=="Active")
 {
    echo "<script language='javascript'>alert('You Have Already Complete Your Payment Process');window.location='index.php'</script>";
    exit();
}
?>
    <div class="container">
        <header>
            <img src="img/img.png" alt="" width="100px;" height="100px;">
            <img class="imp" src="img/imp.png" alt="In Association With" width="300px;" height="100px;" >
            

            <h2>TEKVISORY PRESENTS</h2>

            <h2>TECH WIZARDS 2.0 
            
            </h2>
            <h3>Payment Form</h3>

           
            
        </header>




         
  <div class="col-sm-6" style="align-content: center;">
    <div class="card">
      <div class="card-body">
       
<?php




$updatedatatstudentquery=mysqli_query($con,"SELECT * FROM `registration` WHERE `receipt_number`='$id'");
$result=mysqli_fetch_assoc($updatedatatstudentquery)or die("");

$studentcampusid=$result['student_campus'];
$studentcourseid=$result['student_course'];



$campusnamequery=mysqli_query($con,"SELECT * FROM `campus` WHERE `campus_id`='$studentcampusid'");
$resultcampusname=mysqli_fetch_assoc($campusnamequery)or die("");
$campusname=$resultcampusname['campus_name'];

$coursenamequery=mysqli_query($con,"SELECT * FROM `course_detail` WHERE `course_id2`='$studentcourseid'");
$resultcoursename=mysqli_fetch_assoc($coursenamequery)or die("");
$coursename=$resultcoursename['course_name'];
  ?>
  <form>
  <div class="card-body">
    <h5 class="card-title"></h5>
    <p class="card-text"><b>Amount:-</b> ₹50</p>
    <input type="hidden" name="TotalAmount" id="TotalAmount" value="1">
     <input type="hidden" name="receiptnumber" id="receiptnumber" value="<?php echo $id;?>">
      <p class="card-text"><b>Admission Id:-</b> <?php echo $result['student_id']; ?></p>
      <input type="hidden" name="student_id" id="student_id" value="<?php echo $result['student_id']; ?>">
      <p class="card-text"><b>Date Of Birth:-</b> <?php echo $result['student_dob'] ; ?></p>
      <p class="card-text"><b>Campus:-</b> <?php echo $campusname ; ?> </p>
      <p class="card-text"><b>Course:-</b> <?php echo $coursename ; ?></p>
       <p class="card-text"><b>Semester:-</b> <?php echo $result['student_semester'] ; ?> </p>
      <p class="card-text"><b>Number:-</b> <?php echo $result['student_number'] ; ?> </p>
      <p class="card-text"><b>Email:-</b>  <?php echo $result['student_email'] ; ?> </p>
      <p class="card-text"><b>Date:-</b>   <?php echo date('d-m-Y'); ?> </p><br>
      <input type="hidden" name="cdate" id="cdate" value="<?php echo  date('d-m-Y'); ?>">
      <input type="button" name="btn" id="btn" value="Pay Now" onclick="pay_now()"/>

  </div>
</form>
      </div>
    </div>
  </div>
  </div>
 
<script>
    function pay_now(){
        var receiptnumber=jQuery('#receiptnumber').val();
        var TotalAmount=jQuery('#TotalAmount').val();
        var student_id=jQuery('#student_id').val();
        var cdate=jQuery('#cdate').val();
        
         jQuery.ajax({
               type:'POST',
               url:'payment_process.php',
               data:"TotalAmount="+TotalAmount+"&receiptnumber="+receiptnumber+"&student_id="+student_id+"&cdate="+cdate,
               success:function(result){
                   var options = {
                        "key": "rzp_live_e2BYa4t7HqfzX1", 
                        "amount": TotalAmount*100, 
                        "currency": "INR",
                        "name": "Tech Wizard 2.0",
                        "description": "Payment Of Tech Wizard",
                        "image": "https://techwizard.geumca.in/img/logo.png",
                        "handler": function (response){
                           jQuery.ajax({
                               type:'POST',
                               url:'payment_process.php',
                               data:"invoice_number="+response.razorpay_payment_id,

                               success:function(result){
                                 
                                 window.alert("Thank You For Payment Your Payment is Successfully Completed")
                                 window.alert("Soon You Will a recevied mail Form Tech Wizard Team with 24 hours")
                                
                                   window.location.href="index.php";
                               }
                           });
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.open();
               }
           });
        
        
    }
</script>

</body>
</html>